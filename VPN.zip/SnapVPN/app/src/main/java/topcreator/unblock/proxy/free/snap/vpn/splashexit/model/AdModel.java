package topcreator.unblock.proxy.free.snap.vpn.splashexit.model;

public class AdModel {
    private String adMobAppID = "";
    private String adMobBanner = "";
    private String adMobInter = "";
    private String adMobNative = "";
    private String ironAppKey = "";
    private int isAdmobEnable = 0;
    private int isIronEnable = 0;
    private String privacy = "";
    private String moreApps = "";

    public String getAdMobAppID() {
        return adMobAppID;
    }

    public void setAdMobAppID(String adMobAppID) {
        this.adMobAppID = adMobAppID;
    }

    public String getAdMobBanner() {
        return adMobBanner;
    }

    public void setAdMobBanner(String adMobBanner) {
        this.adMobBanner = adMobBanner;
    }

    public String getAdMobInter() {
        return adMobInter;
    }

    public void setAdMobInter(String adMobInter) {
        this.adMobInter = adMobInter;
    }

    public String getAdMobNative() {
        return adMobNative;
    }

    public void setAdMobNative(String adMobNative) {
        this.adMobNative = adMobNative;
    }

    public String getIronAppKey() {
        return ironAppKey;
    }

    public void setIronAppKey(String ironAppKey) {
        this.ironAppKey = ironAppKey;
    }

    public int getIsAdmobEnable() {
        return isAdmobEnable;
    }

    public void setIsAdmobEnable(int isAdmobEnable) {
        this.isAdmobEnable = isAdmobEnable;
    }

    public int getIsIronEnable() {
        return isIronEnable;
    }

    public void setIsIronEnable(int isIronEnable) {
        this.isIronEnable = isIronEnable;
    }

    public String getPrivacy() {
        return privacy;
    }

    public void setPrivacy(String privacy) {
        this.privacy = privacy;
    }

    public String getMoreApps() {
        return moreApps;
    }

    public void setMoreApps(String moreApps) {
        this.moreApps = moreApps;
    }



    public AdModel() {

    }

   }
