package topcreator.unblock.proxy.free.snap.vpn.activity;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.DisplayMetrics;
import android.view.Display;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import topcreator.unblock.proxy.free.snap.vpn.R;
import topcreator.unblock.proxy.free.snap.vpn.adapter.BookmarkServerListAdapter;
import topcreator.unblock.proxy.free.snap.vpn.model.Server;
import topcreator.unblock.proxy.free.snap.vpn.splashexit.Splash_Activity;

import java.util.List;


public class BookmarkServerListActivity extends BaseActivity {
    private FrameLayout adMobView;
    private InterstitialAd mInterstitialAdMob;
    private boolean add = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark_server_list);

        initAdmobFullAd(this);
        loadAdmobAd();

        toolbar.setTitle("BookMark");

        adMobView = (FrameLayout) findViewById(R.id.adMobView);
        showBanner();
    }

    @Override
    protected void onResume() {
        super.onResume();
        final List<Server> serverList = dbHelper.getBookmarks();
        BookmarkServerListAdapter adapter = new BookmarkServerListAdapter(serverList, this, dbHelper);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.bookmarkRv);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(llm);
        recyclerView.setAdapter(adapter);
    }

    private void showBanner() {
        final AdView mAdView = new AdView(this);
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    public void initAdmobFullAd(Context context) {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            return;
        }
        mInterstitialAdMob = new com.google.android.gms.ads.InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(Splash_Activity.adModel.getAdMobInter());
        mInterstitialAdMob.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }

            @Override
            public void onAdLeftApplication() {
                super.onAdLeftApplication();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });
    }

    public void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    public void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }

    public boolean isAdmobLoaded() {
        if (mInterstitialAdMob != null) {
            return mInterstitialAdMob.isLoaded();
        } else {
            return false;
        }
    }

    public void showadd(Intent intent) {
        if (add) {
            startActivity(intent);
            if (Splash_Activity.adModel.getIsAdmobEnable() == 1 && isAdmobLoaded()) {
                showAdmobInterstitial();
            }
            add = false;
        } else {
            startActivity(intent);
            add = true;
        }
    }

}
