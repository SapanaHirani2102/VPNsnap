package topcreator.unblock.proxy.free.snap.vpn.activity;

import android.content.Context;
import android.content.Intent;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import topcreator.unblock.proxy.free.snap.vpn.R;
import topcreator.unblock.proxy.free.snap.vpn.adapter.ServerListAdapter;
import topcreator.unblock.proxy.free.snap.vpn.model.Server;

import java.util.List;

import de.blinkt.openvpn.core.VpnStatus;
import topcreator.unblock.proxy.free.snap.vpn.splashexit.Splash_Activity;

public class ServersListActivity extends BaseActivity {
    private ListView listView;
    private ServerListAdapter serverListAdapter;
    private FrameLayout adMobView;
    private InterstitialAd mInterstitialAdMob;
    private boolean add = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servers_list);

        toolbar.setTitle("Server");
        if (!VpnStatus.isVPNActive())
            connectedServer = null;

        initAdmobFullAd(this);
        loadAdmobAd();

        listView = (ListView) findViewById(R.id.list);

        adMobView = (FrameLayout) findViewById(R.id.adMobView);
        showBanner();
    }

    @Override
    protected void onResume() {
        super.onResume();

        invalidateOptionsMenu();

        buildList();
    }

    @Override
    protected void ipInfoResult() {
        serverListAdapter.notifyDataSetChanged();
    }

    private void buildList() {
        String country = getIntent().getStringExtra(HomeActivity.EXTRA_COUNTRY);
        final List<Server> serverList = dbHelper.getServersByCountryCode(country);
        serverListAdapter = new ServerListAdapter(this, serverList);

        listView.setAdapter(serverListAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Server server = serverList.get(position);
                BaseActivity.sendTouchButton("detailsServer");
                Intent intent = new Intent(ServersListActivity.this, ServerActivity.class);
                intent.putExtra(Server.class.getCanonicalName(), server);
                showadd(intent);
            }
        });

        getIpInfo(serverList);
    }

    private void showBanner() {
        final AdView mAdView = new AdView(this);
        mAdView.setAdSize(getAdSize());
        mAdView.setAdUnitId(Splash_Activity.adModel.getAdMobBanner());
        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                if (adMobView != null) {
                    adMobView.removeAllViews();
                }
                adMobView.addView(mAdView);
            }
        });
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        if (adMobView != null) {
            adMobView.removeAllViews();
        }
    }

    private com.google.android.gms.ads.AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return com.google.android.gms.ads.AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }


    public void initAdmobFullAd(Context context) {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            return;
        }
        mInterstitialAdMob = new com.google.android.gms.ads.InterstitialAd(context);
        mInterstitialAdMob.setAdUnitId(Splash_Activity.adModel.getAdMobInter());
        mInterstitialAdMob.setAdListener(new com.google.android.gms.ads.AdListener() {
            @Override
            public void onAdClosed() {
                loadAdmobAd();
            }

            @Override
            public void onAdLoaded() {

            }

            @Override
            public void onAdOpened() {
                //   super.onAdOpened();
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
            }

            @Override
            public void onAdLeftApplication() {
                super.onAdLeftApplication();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });
    }

    public void loadAdmobAd() {
        if (mInterstitialAdMob != null && !mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
        }
    }

    public void showAdmobInterstitial() {
        if (mInterstitialAdMob != null && mInterstitialAdMob.isLoaded()) {
            mInterstitialAdMob.show();
        }
    }

    public boolean isAdmobLoaded() {
        if (mInterstitialAdMob != null) {
            return mInterstitialAdMob.isLoaded();
        } else {
            return false;
        }
    }

    public void showadd(Intent intent) {
        if (add) {
            startActivity(intent);
            if (Splash_Activity.adModel.getIsAdmobEnable() == 1 && isAdmobLoaded()) {
                showAdmobInterstitial();
            }
            add = false;
        } else {
            startActivity(intent);
            add = true;
        }
    }


}