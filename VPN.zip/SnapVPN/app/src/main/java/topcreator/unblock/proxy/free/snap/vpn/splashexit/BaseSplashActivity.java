package topcreator.unblock.proxy.free.snap.vpn.splashexit;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.NativeContentAd;
import com.google.android.gms.ads.formats.NativeContentAdView;
import topcreator.unblock.proxy.free.snap.vpn.R;

import java.util.List;

public class BaseSplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public void showGOOGLEAdvance1(final FrameLayout frameLayout) {
        AdLoader.Builder builder = new AdLoader.Builder(this, Splash_Activity.adModel.getAdMobNative());
        builder.forContentAd(new NativeContentAd.OnContentAdLoadedListener() {
            public void onContentAdLoaded(NativeContentAd nativeContentAd) {
                NativeContentAdView nativeContentAdView = (NativeContentAdView) getLayoutInflater().inflate(R.layout.splash_admob_native, null);
                populateContentAdView(nativeContentAd, nativeContentAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(nativeContentAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().setStartMuted(false).build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    public void populateContentAdView(NativeContentAd nativeContentAd, NativeContentAdView nativeContentAdView) {
        TextView contentad_headline = (TextView) nativeContentAdView.findViewById(R.id.contentad_headline);
        TextView sponsored_label = (TextView) nativeContentAdView.findViewById(R.id.sponsored_label);
        TextView contentad_body = (TextView) nativeContentAdView.findViewById(R.id.contentad_body);
        TextView contentad_advertiser = (TextView) nativeContentAdView.findViewById(R.id.contentad_advertiser);
        TextView contentad_call_to_action = (TextView) nativeContentAdView.findViewById(R.id.contentad_call_to_action);


        nativeContentAdView.setHeadlineView(nativeContentAdView.findViewById(R.id.contentad_headline));
        nativeContentAdView.setImageView(nativeContentAdView.findViewById(R.id.contentad_image));
        nativeContentAdView.setBodyView(nativeContentAdView.findViewById(R.id.contentad_body));
        nativeContentAdView.setCallToActionView(nativeContentAdView.findViewById(R.id.contentad_call_to_action));
        nativeContentAdView.setLogoView(nativeContentAdView.findViewById(R.id.contentad_logo));
        nativeContentAdView.setAdvertiserView(nativeContentAdView.findViewById(R.id.contentad_advertiser));
        ((TextView) nativeContentAdView.getHeadlineView()).setText(nativeContentAd.getHeadline());
        ((TextView) nativeContentAdView.getBodyView()).setText(nativeContentAd.getBody());
        ((TextView) nativeContentAdView.getCallToActionView()).setText(nativeContentAd.getCallToAction());
        ((TextView) nativeContentAdView.getAdvertiserView()).setText(nativeContentAd.getAdvertiser());
        List images = nativeContentAd.getImages();
        if (images.size() > 0) {
            ((ImageView) nativeContentAdView.getImageView()).setImageDrawable(((com.google.android.gms.ads.formats.NativeAd.Image) images.get(0)).getDrawable());
        }
        com.google.android.gms.ads.formats.NativeAd.Image logo = nativeContentAd.getLogo();
        if (logo == null) {
            nativeContentAdView.getLogoView().setVisibility(View.INVISIBLE);
        } else {
            ((ImageView) nativeContentAdView.getLogoView()).setImageDrawable(logo.getDrawable());
            nativeContentAdView.getLogoView().setVisibility(View.VISIBLE);
        }
        nativeContentAdView.setNativeAd(nativeContentAd);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}
