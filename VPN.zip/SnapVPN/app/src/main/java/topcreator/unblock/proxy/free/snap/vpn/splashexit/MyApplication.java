package topcreator.unblock.proxy.free.snap.vpn.splashexit;

import android.app.Application;

import com.onesignal.OneSignal;

public class MyApplication extends Application {

    private static MyApplication instance;
    public void onCreate() {
        super.onCreate();

        OneSignal.startInit(this)
                .autoPromptLocation(false) // default call promptLocation later
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .filterOtherGCMReceivers(true)
                .init();

        instance = this;

    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public static MyApplication getInstance() {
        return instance;
    }
}
