package topcreator.unblock.proxy.free.snap.vpn.splashexit;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class AppCommon {
    public final static int AD_ADMOB = 1;
    public final static int AD_FB = 2;
    public final static int AD_APP_NEXT = 3;

    public static Boolean CheckNet(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}
